using System.Text.Json;

namespace customer_product_api.Data;

public static class JsonDataStore
{
    private static string jsonFile = "Data/mock-data.json";

    public static async Task<DataModel> LoadAsync()
    {
        if (!File.Exists(jsonFile)) return new DataModel();

        var json = await File.ReadAllTextAsync(jsonFile);
        var options = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };
        return JsonSerializer.Deserialize<DataModel>(json,options) ?? new DataModel();
    }

    public static async Task SaveAsync(DataModel data)
    {
        var json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
        await File.WriteAllTextAsync(jsonFile, json);
    }
}
