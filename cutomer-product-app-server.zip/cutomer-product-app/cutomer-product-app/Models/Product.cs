﻿namespace cutomer_product_app.Models
{
    public class Product
    {
        public long ProductId { get; set; }
        public long CustomerId { get; set; }  
        public string ProductName { get; set; }
        public decimal Price { get; set; }
    }

}
