using cutomer_product_app.Models;

public class DataModel
{
    public List<Customer> Customers { get; set; } = new();
    public List<Product> Products { get; set; } = new();
}
