﻿namespace cutomer_product_app.Models
{
    public class Customer
    {
        public long CustomerId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        
    }

}
