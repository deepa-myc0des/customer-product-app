using customer_product_api.Data;
using cutomer_product_app.Models;

public class CustomerService : ICustomerService
{
    public async Task<IEnumerable<Customer>> GetAllAsync()
    {
        var data = await JsonDataStore.LoadAsync();
        return data.Customers;
    }

    public async Task<Customer?> GetByIdAsync(int id)
    {
        var data = await JsonDataStore.LoadAsync();
        return data.Customers.FirstOrDefault(c => c.CustomerId == id);
    }

}
