using customer_product_api.Data;
using cutomer_product_app.Models;

public class ProductService : IProductService
{
    public async Task<Product?> GetByIdAsync(int id)
    {
        var data = await JsonDataStore.LoadAsync();
        return data.Products.FirstOrDefault(p => p.ProductId == id);
    }

    public async Task<IEnumerable<Product>> GetProductsForCustomerAsync(int customerId)
    {
        var data = await JsonDataStore.LoadAsync();
        return data.Products.Where(p => p.CustomerId == customerId);
    }

    public async Task<Product> AddAsync(Product product)
    {
        var data = await JsonDataStore.LoadAsync();
        product.ProductId = data.Products.Any() ? data.Products.Max(p => p.ProductId) + 1 : 1;
        data.Products.Add(product);
        await JsonDataStore.SaveAsync(data);
        return product;
    }

    public async Task<Product?> UpdateAsync(int id, Product updated)
    {
        var data = await JsonDataStore.LoadAsync();
        var product = data.Products.FirstOrDefault(p => p.ProductId == id);
        if (product == null) return null;

        product.ProductName = updated.ProductName;
        product.Price = updated.Price;
        await JsonDataStore.SaveAsync(data);
        return product;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var data = await JsonDataStore.LoadAsync();
        var product = data.Products.FirstOrDefault(p => p.ProductId == id);
        if (product == null) return false;

        data.Products.Remove(product);
        await JsonDataStore.SaveAsync(data);
        return true;
    }
}
