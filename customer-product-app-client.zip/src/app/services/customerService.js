import http from "./httpClient "; 


export async function getCustomers() {
  const response = await http.get(`/customer`);
  return response.data;
}

export async function getCustomerById(id) {
  const response = await http.get(`/customer/${id}`);
  return response.data;
}

