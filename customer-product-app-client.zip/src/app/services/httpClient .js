import axios from "axios";
import { environment } from '../../environments/environment';
const api_url = `${environment.apiUrl}`;


const httpClient  = axios.create({
  baseURL: api_url, 
  headers: {
    "Content-Type": "application/json",
  },
});

export default httpClient ;
