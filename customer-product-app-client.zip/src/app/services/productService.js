import http from "./httpClient "; 

export async function getProductsByCustomer(customerId) {
  const response = await http.get(`/product/${customerId}/customer`);
  return response.data;
}

export async function addProduct(product) {
  const response = await http.post(`/product`, product);
  return response.data;
}

export async function updateProduct(productId, product) {
  const response = await http.put(`/product/${productId}`, product);
  return response.data;
}

export async function deleteProduct(productId) {
  const response = await http.delete(`/product/${productId}`);
  return response.data;
}
