import React, { useState } from "react";
import { TextField, Button, Stack, Paper } from "@mui/material";
import { addProduct } from "../../services/productService"; // Adjust path

function AddProduct({ customerId, onSave, onCancel }) {
  const [productName, setName] = useState("");
  const [price, setPrice] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!productName || isNaN(price)) return;

    const product = {
      productName,
      price: parseFloat(price),
      customerId: customerId,
    };

    try {
      const addedProduct = await addProduct(product);
      if (onSave) onSave(addedProduct); 
      setName("");
      setPrice("");
    } catch (error) {
      alert("Failed to add product.");
    }
  };


  return (
    <Paper elevation={2} sx={{ p: 2, mb: 2 }}>
      <form onSubmit={handleSubmit}>
      
        <Stack spacing={2}>
          <TextField
            label="Product Name"
            variant="outlined"
            size="small"
            fullWidth
            value={productName}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <TextField
            label="Price"
            variant="outlined"
            size="small"
            fullWidth
            type="number"
            inputProps={{ min: 0, step: 0.01 }}
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
          />
          <Stack direction="row" spacing={2}>
            <Button type="submit" variant="contained" color="primary">
              Save
            </Button>
            <Button variant="outlined" onClick={onCancel}>
              Cancel
            </Button>
          </Stack>
        </Stack>
      </form>
    </Paper>
  );
}

export default AddProduct;
