import React, { useState, useEffect } from "react";
import {
  TextField,
  Button,
  Stack,
  Paper,
} from "@mui/material";
import { updateProduct } from "../../services/productService"; 

function EditProduct({ product, onSave, onCancel }) {
  const [productName, setName] = useState("");
  const [price, setPrice] = useState("");

  useEffect(() => {
    if (product) {
      setName(product.productName || "");
      setPrice(product.price?.toString() || "");
    }
  }, [product]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!productName || isNaN(price)) return;

    const updated = {
      ...product,
      productName,
      price: parseFloat(price),
    };

    try {
      await updateProduct(product.productId, updated);
      if (onSave) onSave(updated); 
    } catch (error) {
      console.error("Failed to update product:", error);
      alert("Update failed.");
    }
  };

  if (!product) return null;

  return (
    <Paper elevation={2} sx={{ p: 2, mb: 2 }}>
      <form onSubmit={handleSubmit}>
        <Stack spacing={2}>
          

          <TextField
            label="Product Name"
            variant="outlined"
            size="small"
            fullWidth
            value={productName}
            onChange={(e) => setName(e.target.value)}
            required
          />

          <TextField
            label="Price"
            variant="outlined"
            size="small"
            fullWidth
            type="number"
            inputProps={{ min: 0, step: 0.01 }}
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
          />

          <Stack direction="row" spacing={2}>
            <Button type="submit" variant="contained" color="primary">
              Update
            </Button>
            <Button variant="outlined" onClick={onCancel}>
              Cancel
            </Button>
          </Stack>
        </Stack>
      </form>
    </Paper>
  );
}

export default EditProduct;
