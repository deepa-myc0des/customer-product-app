import React, { useEffect, useState } from "react";
import { DataGrid } from "@mui/x-data-grid";
import * as productsService from "../../services/productService";
import EditProductForm from "./editProduct";
import AddProductForm from "./addProduct";
import {
  Button,
  IconButton,
  Menu,
  MenuItem,
  Alert,
  Collapse,
} from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import DeleteIcon from "@mui/icons-material/Delete";

const PRODUCTS_PER_PAGE = 6;

export default function ProductList({ customerId }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [adding, setAdding] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [anchorEls, setAnchorEls] = useState({});
  const [alertMsg, setAlertMsg] = useState("");
  const [showAlert, setShowAlert] = useState(false);

  useEffect(() => {
    if (!customerId) return;
    setLoading(true);
    productsService
      .getProductsByCustomer(customerId)
      .then((data) => {
        setProducts(data || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, [customerId]);

  const triggerAlert = (message) => {
    setAlertMsg(message);
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 3000);
  };

  const handleAdd = async (newProduct) => {
  setAdding(false); 
   try {
      const data = await productsService.getProductsByCustomer(customerId);
      setProducts(data || []);
      triggerAlert("Product added successfully!");
    } catch (err) {
      console.error("Failed to add product:", err);
    }
  };

  const handleUpdate = async (updatedProduct) => {
    setEditingId(null);
    try {
      await productsService.updateProduct(
        updatedProduct.productId,
        updatedProduct
      );
      const data = await productsService.getProductsByCustomer(customerId);
      setProducts(data || []);
      triggerAlert("Product updated successfully!");
    } catch (err) {
      console.error("Failed to update product:", err);
    }
  };

  const handleDelete = async (id) => {
    handleMenuClose(id);
    try {
      await productsService.deleteProduct(id);
      const data = await productsService.getProductsByCustomer(customerId);
      setProducts(data || []);
      triggerAlert("Product deleted successfully!");
    } catch (err) {
      console.error("Failed to delete product:", err);
    }
  };

  const handleMenuOpen = (event, id) => {
    event.stopPropagation();
    setAnchorEls((prev) => ({ ...prev, [id]: event.currentTarget }));
  };

  const handleMenuClose = (id) => {
    setAnchorEls((prev) => ({ ...prev, [id]: null }));
  };

  const columns = [
    { field: "productId", headerName: "ID", width: 80 },
    { field: "productName", headerName: "Product Name", flex: 1 },
    {
      field: "price",
      headerName: "Price",
      width: 120,
      valueFormatter: (params) => {
        return `$${Number(params).toFixed(2)}`;
      },
    },
    {
      field: "actions",
      headerName: "Actions",
      width: 100,
      sortable: false,
      renderCell: (params) => {
        const id = params.row.productId;
        return (
          <>
            <IconButton
              onClick={(e) => {
                e.stopPropagation();
                handleMenuOpen(e, id);
              }}
              size="small"
            >
              <MoreVertIcon />
            </IconButton>
            <Menu
              anchorEl={anchorEls[id]}
              open={Boolean(anchorEls[id])}
              onClose={() => handleMenuClose(id)}
            >
              <MenuItem
                onClick={() => {
                  handleDelete(id);
                  handleMenuClose(id);
                }}
              >
                <DeleteIcon fontSize="small" sx={{ mr: 1 }} /> Delete
              </MenuItem>
            </Menu>
          </>
        );
      },
    },
  ];

  return (
    <div className="product-list-container">
      <Collapse in={showAlert}>
        <Alert severity="success" sx={{ mb: 2 }}>
          {alertMsg}
        </Alert>
      </Collapse>

      <div
        className="product-list-header"
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: 16,
        }}
      >
        <h2 className="text-xl font-bold">Products ({products.length})</h2>
        {!adding && (
          <Button
            variant="contained"
            color="primary"
            onClick={() => setAdding(true)}
            sx={{ textTransform: "none" }}
          >
            Add Product
          </Button>
        )}
      </div>

      {adding && (
        <AddProductForm
          customerId={customerId}
          onSave={handleAdd}
          onCancel={() => setAdding(false)}
        />
      )}

      {editingId && (
        <EditProductForm
          product={products.find((p) => p.productId === editingId)}
          onSave={handleUpdate}
          onCancel={() => setEditingId(null)}
        />
      )}

      {!adding && !editingId && (
        <div
          className="product-grid-wrapper"
          style={{ height: 400, width: "100%" }}
        >
          <DataGrid
            rows={products}
            columns={columns}
            getRowId={(row) => row.productId}
            pageSize={PRODUCTS_PER_PAGE}
            rowsPerPageOptions={[PRODUCTS_PER_PAGE]}
            pagination
            onRowClick={(params) => setEditingId(params.row.productId)}
            loading={loading}
            disableSelectionOnClick
          />
        </div>
      )}
    </div>
  );
}
