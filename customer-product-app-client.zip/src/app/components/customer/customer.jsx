import React, { useEffect, useState } from "react";
import * as customerService from "../../services/customerService";
import { Paper, Typography, CircularProgress, Stack } from "@mui/material";

function Customer({ customerId }) {
  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!customerId) {
      setInfo(null);
      return;
    }

    setLoading(true);
    setError(null);

    customerService
      .getCustomerById(customerId)
      .then((data) => {
        setInfo(data);
      })
      .catch((err) => {
        setError("Failed to load customer info.");
        setInfo(null);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [customerId]);

  if (loading) {
    return (
      <Paper elevation={1} sx={{ p: 3, textAlign: "center" }}>
        <CircularProgress />
      </Paper>
    );
  }

  if (error) {
    return (
      <Paper elevation={1} sx={{ p: 3 }}>
        <Typography color="error" variant="body1">
          {error}
        </Typography>
      </Paper>
    );
  }

  if (!info) {
    return (
      <Paper elevation={1} sx={{ p: 3 }}>
        <Typography variant="body1">Customer not found.</Typography>
      </Paper>
    );
  }

  return (
    <Paper elevation={2} sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Customer Information
      </Typography>

      <Stack spacing={1}>
        <Typography variant="body1">
          <strong>Name:</strong> {info.name}
        </Typography>
        <Typography variant="body1">
          <strong>Email:</strong> {info.email}
        </Typography>
        
      </Stack>
    </Paper>
  );
}

export default Customer;
