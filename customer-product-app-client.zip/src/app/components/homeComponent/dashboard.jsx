import ProductList from "../product/viewProducts";
import CustomerInfo from "../customer/customer";

function Dashboard({ customerId, activeTab }) {
  if (!customerId) {
    return (
      <div className="dashboard-placeholder">Please select a customer</div>
    );
  }

  return (
    <div
      style={{
        flex: 1,
        padding: "2rem",
        backgroundColor: "#f9fafb",
        overflowY: "auto",
      }}
    >
      {activeTab === "info" ? (
        <CustomerInfo customerId={customerId} />
      ) : (
        <ProductList customerId={customerId} />
      )}
    </div>
  );
}

export default Dashboard;
