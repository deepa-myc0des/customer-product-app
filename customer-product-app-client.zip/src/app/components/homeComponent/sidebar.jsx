import React, { useState, useEffect } from "react";
import * as customerService from "../../services/customerService";
import {
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Box,
  Accordion,
  AccordionSummary,
  Typography,
} from "@mui/material";

function Sidebar({ onCustomerSelect, onTabSelect, activeTab }) {
  const [customers, setCustomers] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState("");

  useEffect(() => {
    customerService.getCustomers().then(setCustomers).catch(console.error);
  }, []);

  const handleCustomerChange = (e) => {
    setSelectedCustomer(e.target.value);
    onCustomerSelect(e.target.value);
  };



  return (
    <Box
      sx={{
        width: "25%",
        minHeight: "100vh",
        p: 2,
        borderRight: "1px solid #ccc",
      }}
    >
      <FormControl fullWidth size="small" sx={{ mb: 2 }}>
        <InputLabel id="customer-label">Select Customer</InputLabel>
        <Select
          labelId="customer-label"
          value={selectedCustomer}
          label="Select Customer"
          onChange={handleCustomerChange}
        >
          {customers.map((c) => (
            <MenuItem key={c.customerId} value={c.customerId}>
              {c.name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      <Accordion expanded={false} square>
        <AccordionSummary
          aria-controls="customer-info-content"
          id="customer-info-header"
          onClick={() => onTabSelect("info")}
          sx={{
            cursor: "pointer",
            bgcolor: activeTab === "info" ? "primary.main" : "transparent",
            color: activeTab === "info" ? "white" : "inherit",
            "&:hover": {
              bgcolor: activeTab === "info" ? "primary.dark" : "action.hover",
            },
          }}
        >
          <Typography>Customer Info</Typography>
        </AccordionSummary>
      </Accordion>

      <Accordion expanded={false} square>
        <AccordionSummary
          aria-controls="product-details-content"
          id="product-details-header"
          onClick={() => onTabSelect("products")}
          sx={{
            cursor: "pointer",
            bgcolor: activeTab === "products" ? "primary.main" : "transparent",
            color: activeTab === "products" ? "white" : "inherit",
            "&:hover": {
              bgcolor:
                activeTab === "products" ? "primary.dark" : "action.hover",
            },
          }}
        >
          <Typography>Product Details</Typography>
        </AccordionSummary>
      </Accordion>
    </Box>
  );
}

export default Sidebar;
