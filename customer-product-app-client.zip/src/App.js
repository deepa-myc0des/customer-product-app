import React, { useState } from "react";
import Sidebar from "./app/components/homeComponent/sidebar";
import Dashboard from "./app/components/homeComponent/dashboard";
import "./App.css";

function App() {
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [activeTab, setActiveTab] = useState("info");

  return (
    <div className="app-container">
      <Sidebar
        onCustomerSelect={setSelectedCustomer}
        onTabSelect={setActiveTab}
        activeTab={activeTab}
      />
      <Dashboard customerId={selectedCustomer} activeTab={activeTab} />
    </div>
  );
}

export default App;
